
DATABASES = {
    'default': {
        'ENGINE':'django.db.backends.mysql',
        'NAME':'uxsq',
        'USER':'root',
        'PASSWORD':'123456',
        'HOST':'localhost',
        'PORT':'3306',
    }
}

