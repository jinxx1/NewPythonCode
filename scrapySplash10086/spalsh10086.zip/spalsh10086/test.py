# coding=utf-8
import re
from bs4 import BeautifulSoup
import sqlalchemy
from pymysql.converters import escape_string
import pymysql,datetime
import pandas as pd
import numpy as np
from pandas import Series
import pprint
pd.set_option('display.max_columns',None)
pd.set_option('display.max_rows', None)
pd.set_option('display.width', 5000)
pd.set_option('display.unicode.ambiguous_as_wide', True)
pd.set_option('display.unicode.east_asian_width', True)

def get_timestr(date,outformat = "%Y-%m-%d",combdata = False):
    import time
    time_array = ''
    format_string = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%d %H",
        "%Y-%m-%d",
        "%Y/%m/%d %H:%M:%S",
        "%Y/%m/%d %H:%M",
        "%Y/%m/%d %H",
        "%Y/%m/%d",
        "%Y.%m.%d %H:%M:%S",
        "%Y.%m.%d %H:%M",
        "%Y.%m.%d %H",
        "%Y.%m.%d",
        "%Y年%m月%d日 %H:%M:%S",
        "%Y年%m月%d日 %H:%M",
        "%Y年%m月%d日 %H",
        "%Y年%m月%d日",
        "%Y_%m_%d %H:%M:%S",
        "%Y_%m_%d %H:%M",
        "%Y_%m_%d %H",
        "%Y_%m_%d",
        "%Y%m%d%H:%M:%S",
        "%Y%m%d %H:%M:%S",
        "%Y%m%d %H:%M",
        "%Y%m%d %H",
        "%Y%m%d",
        "%Y%m%d%H%M%S",
        "%Y%m%d %H%M%S",
        "%Y%m%d %H%M",
        "%Y%m%d %H",
        "%Y%m%d",
        "%Y\%m\%d %H:%M:%S",
        "%Y\%m\%d %H:%M",
        "%Y\%m\%d %H",
        "%Y\%m\%d",
        "%Y年%m月%d日%H:%M:%S",
        "%Y年%m月%d日%H:%M",
        "%Y年%m月%d日%H",
        "%Y年%m月%d日",
    ]
    for i in format_string:

        try:
            time_array = time.strptime(date, i)
        except:
            continue

    if not time_array:
        return None
    timeL1 = int(time.mktime(time_array))
    timeL = time.localtime(timeL1)
    if combdata:
        return time.strftime(outformat, timeL),timeL1
    else:
        return time.strftime(outformat,timeL)

def mysqlcon():
    MYSQLINFO = {
        "HOST": "183.6.136.67",
        "DBNAME": "jxtest",
        "USER": "xey",
        "PASSWORD": "xey123456",
        "PORT":3306
    }
    conStr = 'mysql+pymysql://{USER}:{PASSWORD}@{HOST}:{PORT}/{DBNAME}?charset=utf8mb4'.format(USER=MYSQLINFO['USER'],
                                                                                           PASSWORD=MYSQLINFO[
                                                                                               'PASSWORD'],
                                                                                           HOST=MYSQLINFO['HOST'],
                                                                                           PORT=MYSQLINFO['PORT'],
                                                                                           DBNAME=MYSQLINFO[
                                                                                               'DBNAME'])
    mysqlcon = sqlalchemy.create_engine(conStr)
    return mysqlcon

def get_urlList():
    excWord = "SELECT page_url FROM listform10086;"
    alltoup = mysqlcon().execute(excWord)
    return tuple([x[0] for x in alltoup])
# //tr[ @ onmouseout = "cursorOut(this)"]/@onclick
# //tr[ @ onmouseout = "cursorOut(this)"]/td[4]/text()
# //tr[@onmouseout = "cursorOut(this)"]/@onclick|//tr[@onmouseout = "cursorOut(this)"]/td[4]/text()
if __name__ == '__main__':



    wword = '''采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	1
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	2
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	3
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	4
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	5
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	6
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	7
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	8
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	9
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	10
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	11
采购公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2	12
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	1
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	2
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	3
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	4
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	5
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	6
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	7
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	8
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	9
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	10
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	11
候选人公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7	12
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	1
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	2
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	3
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	4
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	5
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	6
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	7
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	8
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	9
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	10
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	11
中选结果公示	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16	12
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	1
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	2
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	3
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	4
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	5
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	6
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	7
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	8
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	9
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	10
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	11
单一来源采购信息公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1	12
资格预审公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=3	1
资格预审公告	https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=3	2'''.split('\n')
    print(wword)
    llist = []
    for i in wword:
        n = i.split('\t')
        ddict = {}
        ddict['subclass'] = n[0]
        ddict['url'] = n[1]
        ddict['pageNum'] = int(n[2])
        llist.append(ddict)
    pprint.pprint(llist)
    print(llist)
