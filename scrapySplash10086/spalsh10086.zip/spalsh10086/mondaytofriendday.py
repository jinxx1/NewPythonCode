from apscheduler.schedulers.blocking import BlockingScheduler
import os

def main():
	os.system("nohup scrapy crawl t10086 >/dev/null 2>&1 &")

if __name__ == '__main__':
	sched = BlockingScheduler()
	sched.add_job(main, 'cron', day_of_week='1-5', hour=0, minute=10)
	sched.start()
