import time,os,datetime
import threading
from time import ctime,sleep

def ListCrawl():
    while True:
        while True:
            with open('onoff.txt', 'r') as f:
                onoff = f.read()
                f.close()
            if onoff == 'artcle':
                time.sleep(1)
            else:
                with open('onoff.txt', 'w') as f:
                    f.write('list')
                    f.flush()
                    f.close()
                break

        with open('spiderNameList.txt', 'r') as f:
            allName = f.read()
            f.close()
        listName = allName.split('\n')

        os.system('scrapy crawl t10086 -a goon=no -a spiderName={}'.format(listName[0]))
        time.sleep(60)
        os.system('scrapy crawl t10086 -a goon=no -a spiderName={}'.format(listName[1]))
        time.sleep(60)
        os.system('scrapy crawl t10086 -a goon=no -a spiderName={}'.format(listName[2]))
        time.sleep(60)
        os.system('scrapy crawl t10086 -a goon=no -a spiderName={}'.format(listName[3]))
        time.sleep(60)
        os.system('scrapy crawl t10086 -a goon=no -a spiderName={}'.format(listName[4]))

        with open('onoff.txt', 'w') as f:
            f.write('rest')
            f.flush()
            f.close()
        time.sleep(3600 * 1)

def ArtcleCrawl():
    while True:
        while True:
            with open('onoff.txt', 'r') as f:
                onoff = f.read()
                f.close()
            if onoff == 'list':
                time.sleep(1)
            else:
                with open('onoff.txt', 'w') as f:
                    f.write('artcle')
                    f.flush()
                    f.close()
                break

        os.system('scrapy crawl artcraw')
        with open('onoff.txt', 'w') as f:
            f.write('rest')
            f.flush()
            f.close()

        WAITIME = 60 * 1
        print('-------------------  休息{}秒。继续抓取  -------------------'.format(WAITIME))
        time.sleep(WAITIME)

threads = []
t1 = threading.Thread(target=ListCrawl)
threads.append(t1)
t2 = threading.Thread(target=ArtcleCrawl)
threads.append(t2)


if __name__ == '__main__':

    for t in threads:
        # t.setDaemon(True)
        t.start()
        sleep(1)



