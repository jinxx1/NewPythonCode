# -*- coding: utf-8 -*-
import scrapy
from scrapy_splash import SplashRequest
import json,pprint,re
from bs4 import BeautifulSoup
from spalsh10086.scrapyParse import *
from spalsh10086.items import Spalsh10086Item
from spalsh10086.mysql_processing import *
from spalsh10086.settings import MYSQLINFO
import sqlalchemy
from spalsh10086.mysql_processing import *


class A100862Spider(scrapy.Spider):
    name = 'artcraw'
    allowed_domains = ['b2b.10086.cn']
    siteName = '移动'
    artclePageUrl = get_urlList()

    def start_requests(self):
        if len(self.artclePageUrl)==0:
            return None
        lua_script = '''
        function main(splash, args)
            function focus(sel)
                splash:select(sel):focus()
            end
            
            splash.images_enabled = false
            splash:set_user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36")
            assert(splash:go(args.url))
            assert(splash:wait(3))
            
            return {
                cookies = splash:get_cookies(),
                }
        end'''

        yield SplashRequest(url='https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2',
                        endpoint="execute",
                        args={
                            "wait": 120,
                            # "timeout": 3600,
                            # "resource_timeout":20,
                            "lua_source": lua_script,
                        },
                        callback=self.parse,
                        )
    def parse(self, response):
        # print(response.data['cookies'])
        article_lua_script = '''
        function main(splash, args)
            splash.resource_timeout = 20
            splash.images_enabled = false
            splash:set_user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36")
            splash:init_cookies(args.scookies)
            assert(splash:go(args.url))
            assert(splash:wait(3))
            
            return {
            html = splash:html(),
            ddict = args.ddict
                  }
        end'''
        
        for i in self.artclePageUrl:
            yield SplashRequest(url=i['page_url'],
                                    endpoint="execute",
                                    args={
                                        "wait": 120,
                                        # "timeout": 3600,
                                        # "resource_timeout": 20,
                                        "lua_source": article_lua_script,
                                        "scookies": response.data['cookies'],
                                        "ddict": str(i),
                                    },
                                    callback=self.parseA,
                                    )

    def parseA(self, response):
        item = Spalsh10086Item()
        content_info = get_content(response.data['html'])
        ddict = json.loads(response.data['ddict'].replace('\'','\"'))

        item['title'] = content_info['title']
        item['content'] = content_info['content']
        item['subclass'] = ddict['subclass']
        item['get_pageNum'] = 9999999999999
        item['issueTime'] = ddict['issue_time']
        item['url'] = ddict['page_url']
        item['site'] = self.allowed_domains[0]
        item['itemID'] = ddict['id']
        yield item


        # csvFileName = r"D:/PythonCode/scrapySplash10086/spalsh10086/spalsh10086/csvall/" + str(ddict['info_id']) + ".json"
        # with open(csvFileName,'w',encoding='utf-8-sig') as f:
        #     json.dump(ddict,f,ensure_ascii=False)
        #     f.flush()
        #     f.close()









