# -*- coding: utf-8 -*-
import scrapy
from scrapy_splash import SplashRequest
import json, pprint, re
from bs4 import BeautifulSoup
from spalsh10086.scrapyParse import *
from spalsh10086.items import Spalsh10086Item
from spalsh10086.mysql_processing import *

class T10086Spider(scrapy.Spider):
	name = 't10086'
	allowed_domains = ['b2b.10086.cn']
	siteName = '移动'

	pageList = [
		{"subclass": "采购公告", "url": "https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=2",
		 'pageCount': 13},
		{"subclass": "候选人公示", "url": "https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=7",
		 'pageCount': 13},
		{"subclass": "中选结果公示", "url": "https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=16",
		 'pageCount': 13},
		{"subclass": "单一来源采购信息公告", "url": "https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=1",
		 'pageCount': 13},
		{"subclass": "资格预审公告", "url": "https://b2b.10086.cn/b2b/main/listVendorNotice.html?noticeType=3",
		 'pageCount': 3},
	]
	lua_script_base = '''
    function main(splash, args)
        function focus(sel)
            splash:select(sel):focus()
        end
        splash.resource_timeout = 20
        splash.images_enabled = false
        splash:set_user_agent("Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko")
        assert(splash:go(args.url))
        assert(splash:wait(3))

        focus('input[id=pageNumber]')
        splash:send_text(args.pageNum)
        assert(splash:wait(3))
        
        splash:select('input[value=GO]'):mouse_click()
        assert(splash:wait(5))
        
        return {
            html = splash:html(),
            get_pageNum = args.pageNum

            }
    end'''

	def __init__(self, goon=None, spiderName=None, *args, **kwargs):
		super(T10086Spider, self).__init__(*args, **kwargs)
		self.goon = goon
		self.lua_script = self.lua_script_base

	def start_requests(self):
		for i in self.pageList:
			for n in range(1,i['pageCount']):
				self.subclass = i['subclass']
				yield SplashRequest(url=i['url'],endpoint="execute",callback=self.parse,
				                    args={
					                    "wait": 0.5,
					                    "timeout":90,
					                    "resource_timeout":10,
					                    "images":0,
					                    "lua_source": self.lua_script,
					                    "pageNum": str(n)
				                    },)

	def parse(self, response):
		article_info = get_IDandTIME(response.data['html'])
		get_pageNum = int(response.data['get_pageNum'])
		noList = depcut(article_info)
		print(article_info[0])
		print('《{}》中,第{}页，共有{}篇文章未录入'.format(self.subclass, get_pageNum, len(noList)))
		if noList:
			pandas_insermysql(noList, self.subclass)
			print('-----------------------------------------------------------------------', get_pageNum)
